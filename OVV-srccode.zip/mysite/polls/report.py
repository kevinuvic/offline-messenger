from django.shortcuts import get_object_or_404, render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status


from django.http import HttpResponse, JsonResponse
from .serializers import ReportSerializer, questionSerializer
from .models import Question, StatusReport
from datetime import datetime 

class bcolors:
    HEADER = '\033[95m'     # magenta
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'    # purple
    FAIL = '\033[91m'       # red
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    

class ReportList(APIView):
    def get(self, request):
        rpts = StatusReport.objects.all()
        serializer = ReportSerializer(rpts, many = True)
        return Response(serializer.data)

def add_report(reporter_id, type, content, timestamp, msgid):
    dtime = datetime.now()   #"YYYY-MM-DD HH:MM[:ss[.uuuuuu]][TZ]"   format
    q = StatusReport(reporter=reporter_id, report_type=type, 
                    report_text=content, report_date=dtime, 
                    msg_id=msgid)
    q.save()
    return

def ack_boardcast(request, receiver_id, timestamp, msg_id):
    if request.method == 'GET':
        add_report(receiver_id, "ACK_BC", "Got a boardcast msg", timestamp, msg_id)
        print(f"{bcolors.HEADER}{bcolors.BOLD}VOTER:{bcolors.ENDC} received a bcast msg@", 
              f"id={bcolors.OKGREEN}{bcolors.UNDERLINE}",                    receiver_id, 
              f"{bcolors.ENDC}, time={bcolors.OKGREEN}{bcolors.UNDERLINE}",  timestamp, 
              f"{bcolors.ENDC}, msgid={bcolors.OKGREEN}{bcolors.UNDERLINE}",  msg_id, 
              f"{bcolors.ENDC}")

        rpts = StatusReport.objects.all()
        serializer = ReportSerializer(rpts, many=True)      #If don't set many=True, AttributeError occurs
        return JsonResponse(serializer.data, safe=False)
    return JsonResponse(serializer.errors, status=400)

def init_boardcast(request, initiator_id, timestamp, msg_id):
    if request.method == 'GET':
        add_report(initiator_id, "INI_BC", "Initiate a boardcast msg", timestamp, msg_id)
        print(f"{bcolors.HEADER}{bcolors.BOLD}MASTER:{bcolors.ENDC} initiate a broadcast@", 
              f"id={bcolors.OKGREEN}{bcolors.UNDERLINE}",                    initiator_id, 
              f"{bcolors.ENDC}, time={bcolors.OKGREEN}{bcolors.UNDERLINE}",  timestamp, 
              f"{bcolors.ENDC}, msgid={bcolors.OKGREEN}{bcolors.UNDERLINE}",  msg_id, 
              f"{bcolors.ENDC}")

        rpts = StatusReport.objects.all()
        serializer = ReportSerializer(rpts, many=True)      #If don't set many=True, AttributeError occurs
        return JsonResponse(serializer.data, safe=False)
    return JsonResponse(serializer.errors, status=400)

def ack_e2emsg(request, receiver_id, timestamp, msg_id):
    if request.method == 'GET':
        add_report(receiver_id, "ACK_E2E", "Got a E2E msg", timestamp, msg_id)
        print(f"{bcolors.HEADER}{bcolors.BOLD}MASTER:{bcolors.ENDC} received a E2E msg@", 
              f"id={bcolors.OKGREEN}{bcolors.UNDERLINE}",                    receiver_id, 
              f"{bcolors.ENDC}, time={bcolors.OKGREEN}{bcolors.UNDERLINE}",  timestamp, 
              f"{bcolors.ENDC}, msgid={bcolors.OKGREEN}{bcolors.UNDERLINE}",  msg_id, 
              f"{bcolors.ENDC}")

        rpts = StatusReport.objects.all()
        serializer = ReportSerializer(rpts, many=True)      #If don't set many=True, AttributeError occurs
        return JsonResponse(serializer.data, safe=False)
    return JsonResponse(serializer.errors, status=400)

def send_e2emsg(request, initiator_id, timestamp, msg_id):
    if request.method == 'GET':
        add_report(initiator_id, "SND_E2E", "Send a E2E msg", timestamp, msg_id)
        print(f"{bcolors.HEADER}{bcolors.BOLD}VOTER:{bcolors.ENDC} Send a E2E msg@", 
              f"id={bcolors.OKGREEN}{bcolors.UNDERLINE}",                    initiator_id, 
              f"{bcolors.ENDC}, time={bcolors.OKGREEN}{bcolors.UNDERLINE}",  timestamp, 
              f"{bcolors.ENDC}, msgid={bcolors.OKGREEN}{bcolors.UNDERLINE}",  msg_id, 
              f"{bcolors.ENDC}")

        rpts = StatusReport.objects.all()
        serializer = ReportSerializer(rpts, many=True)      #If don't set many=True, AttributeError occurs
        return JsonResponse(serializer.data, safe=False)
    return JsonResponse(serializer.errors, status=400)
