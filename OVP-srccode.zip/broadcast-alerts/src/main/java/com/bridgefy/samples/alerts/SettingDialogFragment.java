package com.bridgefy.samples.alerts;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
//import android.support.v4.app.DialogFragment ;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import com.bridgefy.sdk.samples.alerts.R;

public class SettingDialogFragment extends DialogFragment {
    public Activity getHostActivity() {
        return mHostAtv;
    }

    public void setHostActivity(Activity mHostAtv) {
        this.mHostAtv = mHostAtv;
    }
    Activity mHostAtv;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getHostActivity());

        // Get the layout inflater
        //LayoutInflater inflater = requireActivity().getLayoutInflater();
        LayoutInflater inflater = LayoutInflater.from(getHostActivity());

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View customview = inflater.inflate(R.layout.dlg_setting, null);

        //getHostActivity().requestWindowFeature(Window.FEATURE_NO_TITLE);
        builder.setView(customview);

        // Add action buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // sign in the user ...
                        listener.onDialogPositiveClick(SettingDialogFragment.this,
                                mET);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //SettingDialogFragment.this.getDialog().cancel();

                        // Send the negative button event back to the host activity
                        listener.onDialogNegativeClick(SettingDialogFragment.this);
                    }
                });

        {
            Bundle args = getArguments();
            mET[0] = (EditText) (customview.findViewById(R.id.dlg_msgbcsize));
            mET[0].setText(Integer.toString(args.getInt("msgsizeBC")));
            mET[1] = (EditText) (customview.findViewById(R.id.dlg_msge2esize));
            mET[1].setText(Integer.toString(args.getInt("msgsizeE2E")));
            mET[2] = (EditText) (customview.findViewById(R.id.dlg_repeattimes));
            mET[2].setText(Integer.toString(args.getInt("repeattimes")));
            mET[3] = (EditText) (customview.findViewById(R.id.dlg_interval));
            mET[3].setText(Integer.toString(args.getInt("testinverval")));
            for (int i = 0; i < 4; i++) {
                mET[i].setSelectAllOnFocus(true);
            }
        }

        Dialog dlg = builder.create();
        return dlg;
    }

    // to trace the change of input text, then return to the host of dialog
    EditText mET[] = new EditText[4];


    public static SettingDialogFragment newInstance(int msgsizeBC, int msgsizeE2E,
                                                    int repeattimes, int testinterval) {
        SettingDialogFragment f = new SettingDialogFragment();

        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt("msgsizeBC", msgsizeBC);
        args.putInt("msgsizeE2E", msgsizeE2E);
        args.putInt("repeattimes", repeattimes);
        args.putInt("testinverval", testinterval);
        f.setArguments(args);

        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getActivity().requestWindowFeature(Window.FEATURE_NO_TITLE);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //getHostActivity().requestWindowFeature(Window.FEATURE_NO_TITLE);

        View v = inflater.inflate(R.layout.dlg_setting, container, false);
        //View et = v.findViewById(R.id.dlgsetting_msgbcsize);
        //((EditText)et).setText(Integer.toString(111));

        return v;
    }
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        //View et = view.findViewById(R.id.dlgsetting_msgbcsize);
        //((EditText)et).setText(Integer.toString(123));
    }

    /* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
    public interface SettingDialogListener {
        public void onDialogPositiveClick(DialogFragment dialog, EditText value[]);
        public void onDialogNegativeClick(DialogFragment dialog);
    }

    // Use this instance of the interface to deliver action events
    SettingDialogListener listener;

    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (SettingDialogListener) context;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(getActivity().toString()
                    + " must implement NoticeDialogListener");
        }
    }

    //=======================

    public void alertDialogDemo1(Activity host_act) {
        AlertDialog.Builder builder = new AlertDialog.Builder(host_act);    //this.getActivity());
        // Add the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
            }
        });

        // Create the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @TargetApi(21)
    public void alertDialogDemo2(Activity host_act, int args[]) {
        // get alert_dialog.xml view
        LayoutInflater li = LayoutInflater.from(host_act);  //getApplicationContext());
        View customview = li.inflate(R.layout.dlg_setting, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                host_act);  //getApplicationContext());

        // set alert_dialog.xml to alertdialog builder
        alertDialogBuilder.setView(customview);

        {
            mET[0] = (EditText) (customview.findViewById(R.id.dlg_msgbcsize));
            mET[0].setText(Integer.toString(args[0]));
            mET[1] = (EditText) (customview.findViewById(R.id.dlg_msge2esize));
            mET[1].setText(Integer.toString(args[1]));
            mET[2] = (EditText) (customview.findViewById(R.id.dlg_repeattimes));
            mET[2].setText(Integer.toString(args[2]));
            mET[3] = (EditText) (customview.findViewById(R.id.dlg_interval));
            mET[3].setText(Integer.toString(args[3]));
            for (int i = 0; i < 4; i++) {
                mET[i].setSelectAllOnFocus(true);
            }
        }

        // set dialog message
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // get user input and set it to result
                        // edit text
                        //Toast.makeText(getContext(),     //getApplicationContext(),
                        //    "Entered: "+userInput.getText().toString(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }

}
