"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
#from rest_framework.urlpatterns import format_suffix_patterns
from polls import views
from polls import report


urlpatterns = [
    path('', views.index, name='index'),
    path('polls/', include('polls.urls')),
    path('admin/', admin.site.urls),
    
    #url(r'^question/', views.questionList.as_view())
    path('question/', views.questionList.as_view()),
    #path('question/<int:question_id>', views.questionList.as_view()),
    path('questions/', views.question_list),
    path('questions/<int:pk>', views.question_detail),
    path('init_bcast/<str:initiator_id>/<str:timestamp>/<int:msg_id>', report.init_boardcast),
    path('ack_bcast/<str:receiver_id>/<str:timestamp>/<int:msg_id>', report.ack_boardcast),
    path('reports/', report.ReportList.as_view()),
    path('send_e2emsg/<str:initiator_id>/<str:timestamp>/<int:msg_id>', report.send_e2emsg),
    path('ack_e2emsg/<str:receiver_id>/<str:timestamp>/<int:msg_id>', report.ack_e2emsg),
]
