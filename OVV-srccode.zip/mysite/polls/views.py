from django.shortcuts import get_object_or_404, render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import questionSerializer
#from rest_framework.renderers import JSONRenderer
#from rest_framework.parsers import JSONParser
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

#def index(request):
#    return HttpResponse("Hello, world. You're at the polls index.")

from . models import Question
#def index(request):
#    latest_question_list = Question.objects.order_by('-pub_date')[:5]
#    output = ', '.join([q.question_text for q in latest_question_list])
#    return HttpResponse(output)

#def index(request):
#    latest_question_list = Question.objects.order_by('-pub_date')[:5]
#    template = loader.get_template('polls/index.html')
#    context = {
#        'latest_question_list': latest_question_list,
#    }
#    return HttpResponse(template.render(context, request))

def index(request):
    latest_question_list = Question.objects.order_by('-pub_date')[:5]
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context)

# 3 new views
#def detail(request, question_id):
#    return HttpResponse("You're looking at question %s." % question_id)

#def detail(request, question_id):
#    try:
#        question = Question.objects.get(pk=question_id)
#    except Question.DoesNotExist:
#        raise Http404("Question does not exist")
#    return render(request, 'polls/detail.html', {'question': question})
def detail(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/detail.html', {'question': question})

def results(request, question_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % question_id)

def vote(request, question_id):
    return HttpResponse("You're voting on question %s." % question_id)



class questionList(APIView):
    def get(self, request):
        question1 = Question.objects.all()
        serializer = questionSerializer(question1, many = True)
        return Response(serializer.data)
#     def get(self, request, question_id):
#         question1 = Question.objects.filter(id=question_id)
#         serializer = questionSerializer(question1, many = True)
#         return Response(serializer.data)
        
    def post(self):
        pass
    
@csrf_exempt
def question_list(request):
    """
    List all questions, or create a new question.
    """
    if request.method == 'GET':
        qtns = Question.objects.all()
        serializer = questionSerializer(qtns, many=True)
        return JsonResponse(serializer.data, safe=False)

    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = questionSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)
    
@csrf_exempt
def question_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        qtn = Question.objects.get(pk=pk)
    except Quesition.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = questionSerializer(qtn)
        return JsonResponse(serializer.data)

    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = questionSerializer(qtn, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        qtn.delete()
        return HttpResponse(status=204)
