package com.bridgefy.samples.alerts;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.FragmentManager;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
//import android.support.v4.app.DialogFragment;
import android.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.view.View;

import com.bridgefy.sdk.client.Bridgefy;
import com.bridgefy.sdk.client.BridgefyClient;
import com.bridgefy.sdk.client.Message;
import com.bridgefy.sdk.client.MessageListener;
import com.bridgefy.sdk.client.RegistrationListener;
import com.bridgefy.sdk.client.StateListener;
import com.bridgefy.sdk.samples.alerts.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import android.annotation.TargetApi;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.lang3.StringUtils;

import java.util.function.BiConsumer;

import static android.widget.AbsListView.CHOICE_MODE_SINGLE;
import static android.widget.AdapterView.INVALID_POSITION;


public class MainActivity extends AppCompatActivity
        implements SettingDialogFragment.SettingDialogListener {

    private String TAG = "BRIDGEFY_SAMPLE";

    @BindView(R.id.received_alerts)
    TextView receivedAlerts;
    @BindView(R.id.device_text)
    TextView deviceText;
    @BindView(R.id.device_id)
    TextView deviceId;
    @BindView(R.id.sent_alerts)
    TextView sentAlerts;
    @BindView(R.id.fab)
    FloatingActionButton fab;
    @BindView(R.id.fabe2e)
    FloatingActionButton fabe2e;
    private int sentAlertCounter = 0;
    private int receivedAlertCounter = 0;
    Unbinder unbinder;
    private ArrayList<Alert> alertsData = new ArrayList<>();

    String fragmentTag = "alerts_fragment";
    String number = "number";
    String date_sent = "date_sent";
    String device_name = "device_name";
    String msg_payload = "msg_payload";     //Kevin add
    String reply_messagesize = "msg_size";  //Kevin add

    String mSharedPreferenceName = "OVP_settings_data";
    int mMsgBcPayloadsize;      // msg payload size for BC
    int mMsgE2ePayloadsize;     // msg payload size for E2E
    int mTestRepeatNum;         // test repeating times
    int mTestInterval;          // interval time between 2 repeated test

    //Kevin add:
    @BindView(R.id.listNodes)
    ListView mlistView;
    private ArrayList<String> mlistNode;
    private ArrayAdapter<String> mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        unbinder = ButterKnife.bind(this);
        deviceText.setText(Build.MANUFACTURER + " " + Build.MODEL);

        //Kevin add:
        mlistNode = new ArrayList<>();
        mlistNode.add("13b3186a-ea47-4c6b-a340-39bfffa20268");
        //mlistNode.add("1faba71c-1a89-4d10-92e7-0208ed1f4087");
        mlistNode.add("831df11d-6ea7-426d-8110-b8a43d8efeaa");
        mAdapter = new ArrayAdapter<String> (this, android.R.layout.simple_list_item_1, mlistNode);
        mlistView = (ListView)findViewById(R.id.listNodes);
        mlistView.setAdapter(mAdapter);
        mlistView.setItemsCanFocus(true);
        mlistView.setFocusable(true);
        mlistView.setChoiceMode(CHOICE_MODE_SINGLE);
        mlistView.setSelector(android.R.drawable.divider_horizontal_textfield); // show up the selector focus

        //Restore the value from SharedPreferences
        SharedPreferences pref = this.getSharedPreferences(mSharedPreferenceName, MODE_PRIVATE);
        mMsgBcPayloadsize = pref.getInt("msgsizeBC", 0);
        mMsgE2ePayloadsize = pref.getInt("msgsizeE2E", 0);
        mTestRepeatNum = pref.getInt("repeattimes", 0);
        mTestInterval = pref.getInt("testinverval", 0);

        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (isThingsDevice(this)) {
            // enabling bluetooth automatically
            bluetoothAdapter.enable();
        }

        Bridgefy.initialize(getApplicationContext(), "295bace1-f37f-47e4-80b0-d8858bc3e988", new RegistrationListener() {
            @Override
            public void onRegistrationSuccessful(BridgefyClient bridgefyClient) {
                // Important data can be fetched from the BridgefyClient object
                deviceId.setText(bridgefyClient.getUserUuid());

                // Once the registration process has been successful, we can start operations
                Bridgefy.start(messageListener, stateListener);
            }

            @Override
            public void onRegistrationFailed(int i, String e) {
                Log.e(TAG, e);
            }
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }


    public boolean isThingsDevice(Context context) {
        final PackageManager pm = context.getPackageManager();
        return pm.hasSystemFeature("android.hardware.type.embedded");
    }

    StateListener stateListener = new StateListener() {
        @Override
        public void onStarted() {
            Log.i(TAG, "onStarted: Bridgefy started");

            if (isThingsDevice(getApplicationContext())) {
                ///for Android Things devices, we automatically send an alert as soon as possible
                //since there is no UI to do it
                //A message will be dispatched every 10 seconds
                final Handler handler = new Handler();

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        prepareMessage(mMsgBcPayloadsize, 0);
                        handler.postDelayed(this, 10000);
                    }
                });
            }
        }

        @Override
        public void onStartError(String s, int i) {
            switch (i) {
                case (StateListener.INSUFFICIENT_PERMISSIONS):
                    //starting operations will fail if you haven't granted the necessary permissions
                    //request them and try again after they have been granted
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
                    break;
                case (StateListener.LOCATION_SERVICES_DISABLED):
                    //location in the device has been disabled
                    break;
            }
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //retry again after permissions have been granted
            Bridgefy.start(messageListener, stateListener);
        }
    }

    @OnClick(R.id.fab)
    public void onViewClicked() {
        //reply 100 bytes from the recipient for master getting to know who receives the BC msg
        prepareMessage(mMsgBcPayloadsize, 0);
    }

    @OnClick(R.id.fabe2e)
    public void onE2EClicked() {
        String recipientid = getSelectedUid();
        if (recipientid == "") {
            Log.i(TAG, "No uid selected");
            return;
        }
        //For Real-device DEBUG
        //runOnUiThread(new Runnable() { public void run() {
        //    Toast.makeText(getApplicationContext(), "recipientid = " + recipientid, Toast.LENGTH_SHORT).show();
        //}});

        //send e2e message
        sendE2Emessage(recipientid, 1024);  //send 1KB
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();

        // always stop Bridgefy when it's no longer necessary
        Bridgefy.stop();
    }

    MessageListener messageListener = new MessageListener() {
        @Override
        public void onBroadcastMessageReceived(Message message) {
            receivedAlertCounter++;
            receivedAlerts.setText(String.valueOf(receivedAlertCounter));

            HashMap<String, Object> content = message.getContent();

            long sendtime = ((Double) content.get(date_sent)).longValue();
            Alert alert = new Alert(message.getSenderId(),
                    (Integer) content.get(number),
                    (String) content.get(device_name),
                    sendtime);

            alertsData.add(alert);

            //KEVIN Add:
            // Send status report to Web.Server.OVV,
            // sendtime acting as msgid
            String recipientid = deviceId.getText().toString();
            String shortreporterid = recipientid.substring(25);
            queryFromServer("ACK_BC", shortreporterid, sendtime);

            //Add the user id into listNotes.sender
            String senderid = message.getSenderId();
            mlistNode.add(senderid);
            mAdapter.notifyDataSetChanged();

            //Reply to senderid.master who sends the broadcast message, if reply_msgsize > 0.
            int reply_msgsize = ((Integer) content.get(reply_messagesize)).intValue();
            if (reply_msgsize > 0)
                sendE2Emessage(senderid, reply_msgsize);

            //KEVEND Add End

            AlertFragment alertFragment = (AlertFragment) getSupportFragmentManager().findFragmentByTag(fragmentTag);
            if (alertFragment != null) {
                alertFragment.updateList(alertsData);
            }
        }

        //Kevin Add:
        @Override
        //BUG FIX: 20200326, OVV didn't receive the ACK_E2E.
        //         content.get(number) doesn't return Integer but Double,
        //         raise an exception "Can't cast Dobule to Integer"
        public void onMessageReceived(Message message) {

            //For Real-device DEBUG
            //runOnUiThread(new Runnable() { public void run() {
            //    Toast.makeText(getApplicationContext(), "OnMessageReceived, Start", Toast.LENGTH_SHORT).show();
            //}});
            Log.i(TAG, "OnMessageReceived, Start");

            // Do something with the received message
            receivedAlertCounter++;
            receivedAlerts.setText(String.valueOf(receivedAlertCounter));

            HashMap<String, Object> content = message.getContent();

            int sentAlertNum = ((Double) content.get(number)).intValue();
            long sendtime = ((Double) content.get(date_sent)).longValue();
            String sendId = message.getSenderId();
            Alert alert = new Alert(sendId,
                    sentAlertNum,   // (Integer) content.get(number), 20200328: error can't cast double to integer, but
                    (String) content.get(device_name),
                    sendtime);
            alertsData.add(alert);

            //For Real-device DEBUG
            //runOnUiThread(new Runnable() { public void run() {
            //    Toast.makeText(getApplicationContext(), "OnMessageReceived, alertData.Added", Toast.LENGTH_SHORT).show();
            //}});
            Log.i(TAG, "OnMessageReceived, alertData.Added");


            //KEVIN Add:
            // report status to Web.Server.OVV
            // sendtime acting as msgid
            String senderid = deviceId.getText().toString();
            String shortreporterid = senderid.substring(25);
            queryFromServer("ACK_E2E", shortreporterid, sendtime);

            //For Real-device DEBUG
            //runOnUiThread(new Runnable() { public void run() {
            //      Toast.makeText(getApplicationContext(), "OnMessageReceived, QueryFromServer.ACK_E2E", Toast.LENGTH_SHORT).show();
            //}});
            Log.i(TAG, "OnMessageReceived, QueryFromServer.ACK_E2E");

            AlertFragment alertFragment = (AlertFragment) getSupportFragmentManager().findFragmentByTag(fragmentTag);
            if (alertFragment != null) {
                alertFragment.updateList(alertsData);
            }

            //For Real-device DEBUG
            //runOnUiThread(new Runnable() { public void run() {
            //    Toast.makeText(getApplicationContext(), "OnMessageReceived, End", Toast.LENGTH_SHORT).show();
            //}});
            Log.i(TAG, "OnMessageReceived, End");

        };


    };



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_alerts) {
            AlertFragment alertFragment = AlertFragment.newInstance(alertsData);
            getSupportFragmentManager().beginTransaction().add(R.id.content_main, alertFragment, "alerts_fragment").addToBackStack(null).commit();

            return true;
        }
        //Kevin add:
        if (id == R.id.action_bctest) {
            Toast.makeText(getApplicationContext(), "BC TEST", Toast.LENGTH_SHORT).show();

            // Excute the test of broadcast
            BC_test();

            return true;
        }
        if (id == R.id.action_e2etest) {
            Toast.makeText(getApplicationContext(),
                    "E2E TEST", Toast.LENGTH_SHORT).show();

            // Execute the test of E2E
            E2E_test();

            return true;
        }
        if (id == R.id.action_clearSL) {
            Toast.makeText(getApplicationContext(), "Clear Sender List", Toast.LENGTH_SHORT).show();

            clearSenderList();

            return true;
        }
        if (id == R.id.action_setting) {
            showSettingDialog();
            //SettingDialogFragment dlg = new SettingDialogFragment();
            //dlg.alertDialogDemo1(this);
            //int args[] = { mMsgBcPayloadsize, mMsgE2ePayloadsize, mTestRepeatNum, mTestInterval};
            //dlg.alertDialogDemo2(this, args);
            return true;
        }

        //Kevin add end.

        return super.onOptionsItemSelected(item);
    }

    public void showSettingDialog() {
        // Create an instance of the dialog fragment and show it
        //pass the initial value of setting to dialog
        DialogFragment dialog = SettingDialogFragment.newInstance(
                mMsgBcPayloadsize,
                mMsgE2ePayloadsize,
                mTestRepeatNum,
                mTestInterval);
        ((SettingDialogFragment)dialog).setHostActivity(this);
        //dialog.show(getSupportFragmentManager(), "settingdlgOVP");
        FragmentManager fm = this.getFragmentManager();
        dialog.show(fm, "settingdlgOVP");
    }
    // The dialog fragment receives a reference to this Activity through the
    // Fragment.onAttach() callback, which it uses to call the following methods
    // defined by the NoticeDialogFragment.NoticeDialogListener interface
    @Override
    public void onDialogPositiveClick(DialogFragment dialog, EditText valueArray[]) {
        //returned values from dialog
        mMsgBcPayloadsize = new Integer(valueArray[0].getText().toString()).intValue();
        mMsgE2ePayloadsize = new Integer(valueArray[1].getText().toString()).intValue();
        mTestRepeatNum = new Integer(valueArray[2].getText().toString()).intValue();
        mTestInterval = new Integer(valueArray[3].getText().toString()).intValue();

        //Save new value to SharedPreferences
        SharedPreferences.Editor editor = this.getSharedPreferences(mSharedPreferenceName,
                MODE_PRIVATE).edit();
        editor.putInt("msgsizeBC", mMsgBcPayloadsize);
        editor.putInt("msgsizeE2E", mMsgE2ePayloadsize);
        editor.putInt("repeattimes", mTestRepeatNum);
        editor.putInt("testinverval", mTestInterval);
        editor.apply();

        // User touched the dialog's positive button
        //runOnUiThread(new Runnable() { public void run() {
            Toast.makeText(getApplicationContext(), "Ok", Toast.LENGTH_SHORT).show();
        //}});
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {
        // User touched the dialog's negative button
        //runOnUiThread(new Runnable() { public void run() {
            Toast.makeText(getApplicationContext(), "Cancel", Toast.LENGTH_SHORT).show();
        //}});
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().findFragmentByTag(fragmentTag) != null) {
            getSupportFragmentManager().popBackStackImmediate();
        } else {
            super.onBackPressed();
        }
    }

    //Kevin add:
    private void queryFromServer(String service, String reporterid, long msgid) {
        String hostaddr = "http://vschool.publicvm.com", webapi;
        switch (service) {
            case "INIT_BC":
                webapi = "init_bcast";
                break;
            case "ACK_BC":
                webapi = "ack_bcast";
                break;
            case "SEND_E2E":
                webapi = "send_e2emsg";
                break;
            case "ACK_E2E":
                webapi = "ack_e2emsg";
                break;
            default:
                return;
        }

        long tmill = System.currentTimeMillis();
        reporterid = reporterid == "" ? "0" : reporterid;   // avoid reporterid == null

        //expected result: "http://vschool.publicvm.com/ack_bcast/reporterid/reporttime/msgid"
        String address = hostaddr + "/"
                        + webapi + "/"
                        + reporterid + "/"
                        + tmill + "/"
                        + msgid;

        //showProgressDialog();
        HttpUtil.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();

                //can't use Toast, exception occurs
                //Context context = getApplicationContext();
                //Toast.makeText(context, "Success" + responseText, Toast.LENGTH_SHORT).show();

                //... YOU SHOULD USE HANDLER
                //runOnUiThread(new Runnable() { public void run() {
                //    Toast.makeText(getApplicationContext(), "asdf", Toast.LENGTH_SHORT).show();
                //    }});
            }

            @Override
            public void onFailure(Call call, IOException e) {
                //Context context = getApplicationContext();
                //Toast.makeText(context, "Fail to send HTTP-Get", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void clearSenderList() {
        mlistNode.clear();
        mAdapter.notifyDataSetChanged();
    }

    void prepareMessage(int msgSize, int reply_msgsize) {
        sentAlertCounter++;

        //assemble the data that we are about to send
        HashMap<String, Object> data = new HashMap<>();
        data.put(number, sentAlertCounter);
        long tmill = System.currentTimeMillis();
        data.put(date_sent, Double.parseDouble("" + tmill));
        data.put(device_name, Build.MANUFACTURER + " " + Build.MODEL);
        data.put(reply_messagesize, new Integer(reply_msgsize));

        //Kevin ADD:
        String filled = StringUtils.repeat("*", msgSize);
        data.put(msg_payload, filled);

        Message message = Bridgefy.createMessage(data);

        //Kevin ADD: report init_bcast to Offline-Voting-Viewer(OVV)
        String reporterid = deviceId.getText().toString().substring(25);
        queryFromServer("INIT_BC", reporterid, tmill);

        //Broadcast messages are sent to anyone that can receive it
        Bridgefy.sendBroadcastMessage(message);
        sentAlerts.setText(String.valueOf(sentAlertCounter));
    }

    void sendBCmessage(String nullpara, Integer e2e_reply_msgsize) {
        prepareMessage(mMsgBcPayloadsize, e2e_reply_msgsize);
    }

    void sendE2Emessage(String recipientId, Integer msgSize) {
        sentAlertCounter++;

        //assemble the data that we are about to send
        HashMap<String, Object> data = new HashMap<>();
        data.put(number, sentAlertCounter);

        long tmill = System.currentTimeMillis();
        data.put(date_sent, Double.parseDouble("" + tmill));
        data.put(device_name, Build.MANUFACTURER + " " + Build.MODEL);
        //Message message = Bridgefy.createMessage(data);

        //Kevin add:
        String filled = StringUtils.repeat("*", msgSize.intValue());
        data.put(msg_payload, filled);

        // Create a message with the HashMap and the recipient's id
        Message message =new Message.Builder().setContent(data).setReceiverId(recipientId).build();

        //Kevin ADD: report init_bcast to Offline-Voting-Viewer(OVV)
        String reporterid = deviceId.getText().toString();
        String shortrid = reporterid.substring(25);
        queryFromServer("SEND_E2E", shortrid, tmill);

        //Broadcast messages are sent to anyone that can receive it
        Bridgefy.sendMessage(message);
        sentAlerts.setText(String.valueOf(sentAlertCounter));
    }

    void BC_test() {
        //send broadcast message
        //startTimer(10, 1000, 1000, this::sendBCmessage, "Master msg", new Integer(0));
        startTimer(mTestRepeatNum, mTestInterval, mTestInterval, this::sendBCmessage,
                "Master msg", new Integer(0));

/*
        Consumer<String> func = (String s) -> {
            Log.i(TAG, s);
            mlistNode.add(s);
            mAdapter.notifyDataSetChanged();
        };
        startTimer(10, 500, 1000, func, "sid");
*/
    }

    String getSelectedUid() {
        //get the selected sender
        int position = mlistView.getCheckedItemPosition();
        if (position == INVALID_POSITION) {
            Toast.makeText(getApplicationContext(), "No recipient selected", Toast.LENGTH_SHORT).show();
            return "";
        }
        String recipientid = mlistNode.get(position);
        return recipientid;
    }
    void E2E_test() {
//        //get the selected sender
//        int position = mlistView.getCheckedItemPosition();
//        if (position == INVALID_POSITION) {
//            Toast.makeText(getApplicationContext(), "No recipient selected", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        String recipientid = mlistNode.get(position);
        String recipientid = getSelectedUid();
        if (recipientid == "") {
            Log.i(TAG, "No uid selected");
            return;
        }

        //send e2e message
        //TODO: set msgsize in the Dialog
        Integer msgsize = new Integer(mMsgE2ePayloadsize);
        //startTimer(100, 200, 200, this::sendE2Emessage, recipientid, msgsize);
        startTimer(mTestRepeatNum, mTestInterval, mTestInterval, this::sendE2Emessage, recipientid, msgsize);
/*        Consumer<String> func = (String s) -> {
            Log.i(TAG, s);
            mlistNode.add(s);
            mAdapter.notifyDataSetChanged();
        };
        startTimer(100, 100, 200, func, recipientid);
*/
    }

    //------------- Tester Timer-----------------
    Timer timer;
    TimerTask timerTask;
    int total_T, step_T;    // initially step_T=0,
                            // step_T increase total_T after each timing task.
                            // until 0, stop.

    //we are going to use a handler to be able to run in our TimerTask
    final Handler handler = new Handler();

    public void startTimer(int times, int delay, int duration,
                               BiConsumer<String, Integer> testfunc, String arg1, Integer arg2) {
        if (times <= 0) return;
        total_T = times;
        step_T = 0;

        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask(testfunc, arg1, arg2);

        //schedule the timer, after the first delay:500ms the TimerTask will run every duration:1000ms
        timer.schedule(timerTask, delay, duration); //
    }

    @TargetApi(Build.VERSION_CODES.N)
    //public void initializeTimerTask(Consumer<String> testfunc, String arg1) {
    public void initializeTimerTask(BiConsumer<String, Integer> testfunc, String arg1, Integer arg2) {

        timerTask = new TimerTask() {
            public void run() {
                //use a handler to run a toast that shows the current timestamp
                handler.post(new Runnable() {
                    public void run() {
                        if (step_T < total_T) {
                            // Task of Doing Something
                            testfunc.accept(arg1, arg2);
                        } else {
                            //stop the timer, if it's not already null
                            if (timer != null) {
                                timer.cancel();
                                timer = null;
                            }
                        }
                        Log.i(TAG, "step = " + step_T);
                        step_T ++;
                    }
                });
            }
        };
    }

}
