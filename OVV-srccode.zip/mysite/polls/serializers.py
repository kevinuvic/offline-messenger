from rest_framework import serializers
from .models import Question, StatusReport

class questionSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Question
        #fields = ('question_text', 'pub_date')
        fields = '__all__'
        
class ReportSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = StatusReport
        #fields = ('report_text', 'report_date')
        fields = '__all__'